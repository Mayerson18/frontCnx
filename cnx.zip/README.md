#Por favor crear un archivo .env con la variable de entorno 
REACT_APP_URL_API=http://localhost:7071/api
